# co6f14249b468fa5fdd02f1f5

Quick start:

```
$ npm install
$ npm start
````

Head over to https://vitejs.dev/ to learn more about using vite
## i am deepshikha this is a blackjack game i made using react and javascript .

Happy Coding!
